# GreenHarvest — Multi-page Healthy Foods Template

What this update includes
- Multi-page static site:
  - index.html (home / featured products)
  - about.html (separate about & policies page)
  - prices.html (price list for all sample products)
  - groceries.html (category)
  - snacks.html (category)
  - supplements.html (category)
- styles.css (shared styling)
- script.js (shared logic: product data, rendering, filtering, add-to-cart demo)
- 10 sample products with descriptions, prices and placeholder images

How to preview
1. Save all files to a single folder.
2. Open `index.html` in a browser. Navigate to categories, prices and about pages via the header.
3. Use the search box on each category page to filter. The Prices page shows a full price table.

Technical notes
- The product list is embedded in script.js as `productData` (10 example items).
- Category pages use `body` data attributes (data-page="category" and data-category="...") to request filtered rendering.
- Images are placeholder URLs (via.placeholder.com). Replace them with real images as needed.
- The "Add" button is a demo: it increments an in-memory cart counter (not persisted).

Next suggestions
- Replace productData with API calls to a backend or CMS.
- Add localStorage support to persist cart contents across pages.
- Create product detail pages (per-product routes) and link "Details" to them.
- Replace placeholder images with real assets and add alt text accordingly.

License
- Free to use and modify for prototypes and projects.