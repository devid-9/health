// Shared script for all pages: product data, rendering, filtering, cart demo.
// 10 sample products across groceries, snacks, supplements.

const productData = [
  {
    id: "p1",
    name: "Organic Quinoa",
    category: "groceries",
    price: 8.99,
    img: "https://via.placeholder.com/600x400.png?text=Organic+Quinoa",
    description: "Protein-rich whole grain, gluten-free and versatile for salads, bowls and breakfasts."
  },
  {
    id: "p2",
    name: "Raw Almond Butter",
    category: "groceries",
    price: 12.25,
    img: "https://via.placeholder.com/600x400.png?text=Raw+Almond+Butter",
    description: "Creamy almond butter with no added sugar or oils — great on toast or smoothies."
  },
  {
    id: "p3",
    name: "Wild Rice Blend",
    category: "groceries",
    price: 7.5,
    img: "https://via.placeholder.com/600x400.png?text=Wild+Rice+Blend",
    description: "Mix of wild and brown rice for extra texture and nutty flavour."
  },
  {
    id: "p4",
    name: "Kale Chips (Sea Salt)",
    category: "snacks",
    price: 4.5,
    img: "https://via.placeholder.com/600x400.png?text=Kale+Chips",
    description: "Crispy baked kale seasoned with sea salt — a savory, low-calorie snack."
  },
  {
    id: "p5",
    name: "Granola Clusters",
    category: "snacks",
    price: 7.45,
    img: "https://via.placeholder.com/600x400.png?text=Granola+Clusters",
    description: "Oats, nuts and honey clusters — perfect with yogurt or as a cereal."
  },
  {
    id: "p6",
    name: "Dark Chocolate Almonds",
    category: "snacks",
    price: 6.75,
    img: "https://via.placeholder.com/600x400.png?text=Dark+Chocolate+Almonds",
    description: "Roasted almonds dipped in 70% dark chocolate for a mindful treat."
  },
  {
    id: "p7",
    name: "Probiotic Capsules",
    category: "supplements",
    price: 19.99,
    img: "https://via.placeholder.com/600x400.png?text=Probiotic+Capsules",
    description: "Daily probiotic blend for digestive health and balanced gut flora."
  },
  {
    id: "p8",
    name: "Vitamin D3 Drops",
    category: "supplements",
    price: 14.99,
    img: "https://via.placeholder.com/600x400.png?text=Vitamin+D3+Drops",
    description: "Liquid Vitamin D3 for improved absorption and convenient dosing."
  },
  {
    id: "p9",
    name: "Omega-3 Softgels",
    category: "supplements",
    price: 16.99,
    img: "https://via.placeholder.com/600x400.png?text=Omega-3+Softgels",
    description: "High-quality fish oil softgels to support heart and brain health."
  },
  {
    id: "p10",
    name: "Super Greens Powder",
    category: "supplements",
    price: 24.99,
    img: "https://via.placeholder.com/600x400.png?text=Super+Greens+Powder",
    description: "Blend of greens, spirulina and antioxidants to boost daily nutrient intake."
  }
];

const productGrid = document.getElementById('product-grid');
const searchInput = document.getElementById('search');
const categorySelect = document.getElementById('category');
const cartCount = document.getElementById('cart-count');

let cart = [];

/** Render product cards into the grid */
function renderProducts(list) {
  if (!productGrid) return;
  productGrid.innerHTML = '';
  if (!list.length) {
    productGrid.innerHTML = '<p>No products match your search.</p>';
    return;
  }

  list.forEach(p => {
    const card = document.createElement('article');
    card.className = 'product-card';
    card.setAttribute('aria-labelledby', `title-${p.id}`);

    card.innerHTML = `
      <img src="${p.img}" alt="${escapeHtml(p.name)}" loading="lazy" />
      <div class="product-meta">
        <div>
          <div id="title-${p.id}" class="product-title">${escapeHtml(p.name)}</div>
          <div class="product-desc" style="color:#6b7280;font-size:.9rem">${escapeHtml(p.description)}</div>
        </div>
        <div style="text-align:right">
          <div class="product-price">$${p.price.toFixed(2)}</div>
          <div style="font-size:.75rem;color:var(--muted)">${capitalize(p.category)}</div>
        </div>
      </div>
      <div style="display:flex;gap:.4rem;margin-top:.6rem">
        <button class="btn-primary add-to-cart" data-id="${p.id}" aria-label="Add ${escapeHtml(p.name)} to cart">Add</button>
        <button class="btn-ghost details" data-id="${p.id}" aria-label="View details for ${escapeHtml(p.name)}">Details</button>
      </div>
    `;

    productGrid.appendChild(card);
  });

  // Attach add-to-cart handlers
  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.dataset.id;
      addToCart(id);
    });
  });

  // Details placeholder
  document.querySelectorAll('.details').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.dataset.id;
      const p = productData.find(x => x.id === id);
      if (p) {
        alert(`${p.name}\n\n${p.description}\n\nPrice: $${p.price.toFixed(2)}`);
      }
    });
  });
}

function addToCart(productId) {
  cart.push(productId);
  if (cartCount) cartCount.textContent = cart.length;
  const btn = document.querySelector(`.add-to-cart[data-id="${productId}"]`);
  if (btn) {
    btn.textContent = 'Added';
    btn.disabled = true;
    setTimeout(()=>{ btn.textContent='Add'; btn.disabled=false }, 1000);
  }
}

/** Basic escape for inserted text nodes */
function escapeHtml(str){
  return String(str).replace(/[&<>"']/g, (s) => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  })[s]);
}

function capitalize(s){ return s.charAt(0).toUpperCase()+s.slice(1) }

// Filtering logic used on pages that have "product-grid"
function applyFilters(catOverride){
  const q = searchInput ? searchInput.value.trim().toLowerCase() : '';
  const cat = typeof catOverride === 'string' ? catOverride : (categorySelect ? categorySelect.value : 'all');
  let results = productData.filter(p => {
    const matchQuery = !q || (p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
    const matchCat = cat === 'all' || p.category === cat;
    return matchQuery && matchCat;
  });
  renderProducts(results);
}

// Populate prices table on prices.html
function renderPricesTable(){
  const el = document.getElementById('prices-table');
  if (!el) return;
  const table = document.createElement('table');
  table.style.width='100%';
  table.style.borderCollapse='collapse';
  table.innerHTML = `
    <thead>
      <tr style="text-align:left;border-bottom:1px solid #e6e6e6">
        <th style="padding:.6rem">Product</th>
        <th style="padding:.6rem">Category</th>
        <th style="padding:.6rem">Price</th>
      </tr>
    </thead>
    <tbody>
      ${productData.map(p => `
        <tr>
          <td style="padding:.6rem;border-bottom:1px solid #f2f2f2">${escapeHtml(p.name)}</td>
          <td style="padding:.6rem;border-bottom:1px solid #f2f2f2">${capitalize(p.category)}</td>
          <td style="padding:.6rem;border-bottom:1px solid #f2f2f2">$${p.price.toFixed(2)}</td>
        </tr>
      `).join('')}
    </tbody>
  `;
  el.innerHTML = '';
  el.appendChild(table);
}

// Init on DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  // Update cart count if available
  if (cartCount) cartCount.textContent = cart.length;

  // Determine page behavior by data attributes on body
  const body = document.body;
  const page = body && body.dataset && body.dataset.page ? body.dataset.page : 'home';

  if (page === 'home') {
    // For home we show a few featured products (first 6)
    const featured = productData.slice(0, 6);
    if (productGrid) renderProducts(featured);

    if (searchInput) searchInput.addEventListener('input', debounce(()=>applyFilters('all'), 200));
    if (categorySelect) categorySelect.addEventListener('change', applyFilters);
  }

  if (page === 'category') {
    const cat = body.dataset.category || 'all';
    // If there's a category select on the page (index), keep it in sync
    if (categorySelect) {
      categorySelect.value = cat;
      categorySelect.addEventListener('change', applyFilters);
    }
    if (searchInput) searchInput.addEventListener('input', debounce(()=>applyFilters(cat), 200));
    // initial render for category
    applyFilters(cat);
  }

  if (page === 'prices') {
    renderPricesTable();
  }

  // Contact form global handler if present
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Thanks — we received your message!');
      contactForm.reset();
    });
  }
});

// Utility: debounce
function debounce(fn, ms){
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(()=>fn(...args), ms);
  };
}